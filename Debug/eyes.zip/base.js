/**
 * Loads the yellow circle that is base for the smiley
 * Hint: Elements tab
 */
function loadSmileyBase() {
    console.log('Loading base');
    document.getElementById('debug').innerHTML = '<div class="smileyface"></div>';
}